﻿namespace TheGame
{
    public class GamePoint
    {
        public int X;
        public int Y;

        public GamePoint(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}
