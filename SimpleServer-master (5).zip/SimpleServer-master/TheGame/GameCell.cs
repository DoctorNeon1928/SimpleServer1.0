﻿namespace TheGame
{
    public class GameCell
    {
        public string Content { get; set; } = "X";
    }
}
