﻿using Server.MVC;
using System;

namespace Server
{
    public class Games:Controller
    {
        public String Index()
        {
            return "Game List";
        }
    }
}
